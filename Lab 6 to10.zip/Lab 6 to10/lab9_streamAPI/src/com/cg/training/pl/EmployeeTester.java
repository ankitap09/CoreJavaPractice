package com.cg.training.pl;

import java.util.Map;

import com.cg.training.service.EmployeeService;

public class EmployeeTester {
	private static EmployeeService service= new EmployeeService();
	
	public static void main(String[] args) {
		
		System.out.println("1.Find out the sum of salary of all employees. ");
		double totalSal= service.sumOfSalaries();
		System.out.println("Total salary= "+ totalSal);
		System.out.println("--------------------------------");
		
		
		System.out.println("2.List out department names and count of employees in each department. ");
		Map<String,Long> map= service.getDepartments();	       
        map.forEach((dept, count) -> {
            System.out.println(dept + " -> " + count);
        });
        System.out.println("------------------------------");
        
        System.out.println("3.Find out the senior most employee of an organization");
        service.findSeniorMostEmp();
        System.out.println("-------------------------------");
        
        System.out.println("4.List employee name and duration of their service in months and days");
        service.employeeServiceDuration();
        System.out.println("-------------------------------");
        
        System.out.println("5.Find out employees without department.");
        service.listEmployeesWithoutDepartment().stream()
        .forEach(System.out::println);
        System.out.println("---------------------------");
        
        System.out.println("6.Find out department without  employees .");
		/*
		 * Map<String,Long> map1= service.getDepartments(); map1.forEach((dept, count)
		 * -> { System.out.println(dept + " -> " + count);});
		 */
       
        System.out.println("---------------------------");
        
        
        System.out.println("7.Find departments with highest count of employees..");
        
        System.out.println("---------------------------");
        
        
        System.out.println("8.List employee name, hire date and day of week on which employee has started");
        service.showHireDetails();
        System.out.println("-----------------------------");
        
        
        System.out.println("9.List employee name, hire date and day of week for employee started on Friday. (Hint:  Accept the day name for e.g. FRIDAY and list all employees joined on Friday)");
        service.employeesStartingFriday()
        .stream()
        .forEach(System.out::println);
        System.out.println("----------------------------------------");
        
        
        System.out.println("10.List employee�s names and name of manager to whom he/she reports.Create a report in format �employee name reports to manager name");
        
        System.out.println("----------------------------------------");
        
        
        System.out.println("11.List employee name, salary and salary increased by 15%. ");
        
        System.out.println("---------------------------------------------------");
        
        
        System.out.println("12.Find employees who didn�t report to anyone");
        service.getEmployeesWithoutManager()
        .stream().forEach(System.out::println);
        System.out.println("------------------------------------------------");
        
        /*
        System.out.println("13.Create a method to accept first name and last name of manager to print name of all his/her subordinates");
        service.getSubordinates("Steven", "King");
        System.out.println("-----------------------------------------------");
        
        */
        System.out.println("14.Sort by Employee Id");
        service.sortById().stream().forEach(System.out::println);
        System.out.println("-------------------------------------------------------");
        
        
        System.out.println("15.Sort by department Id");
        service.sortByDeptId().stream().forEach(System.out::println);
        System.out.println("-------------------------------------------------------");
        
        
        System.out.println("16.Sort by First Name");
        service.sortByFirstName().stream().forEach(System.out::println);
        System.out.println("-------------------------------------------------------");
      
	
	}

}
