package lab6;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
public class Exercise1 {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		
		HashMap<Integer,String> map = new HashMap<>();
		map.put(1, "Ankita");
		map.put(2, "xyz");
		map.put(3, "stur");
		map.put(4,"lmn");
		
		List<String> s = getValues(map);
		System.out.println("ArrayList after sorting :"+s);
		
	}
	
	public static List<String> getValues(HashMap<Integer, String> map) {

		Collection<String>values = map.values();
		ArrayList<String> s = new ArrayList<String>(values);
		
		System.out.println("ArrayList before sorting :"+s);
		Collections.sort(s);
		
		
		
		return s;
	}

}



/*
 * package lab6;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Excercise11 {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		HashMap<Integer,String> map = new HashMap<Integer,String>();
		
		map.put(1, "abc");
		map.put(2, "xyz");
		map.put(3, "lmn");
		map.put(4,"rst");
		
		
		System.out.println("Hashmap element are :");
		for(Map.Entry<Integer,String> m:map.entrySet()) {
			System.out.println(m.getKey()+"  "+m.getValue());
		}
		
		List<String> list = new ArrayList<>();
		list = getValue(map);
		System.out.println("-----------After sorting---------------------");
		System.out.println(list);

	}
	private static List<String> getValue(HashMap<Integer, String> map) {
		Collection<String> values = map.values();
		
		List<String> list = new ArrayList<>(values);
		System.out.println("------Before sorting----------------");
		System.out.println(list);
		Collections.sort(list);
		return list;
	}

}

 */