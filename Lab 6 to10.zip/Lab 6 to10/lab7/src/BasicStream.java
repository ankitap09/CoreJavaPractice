
/*
import java.util.Arrays;
import java.util.stream.Stream;

public class BasicStream {

 

    public static void main(String[] args) {
        //provide static data as source
        Stream<Integer> stream1=Stream.of(10,5,20,15,25);
        stream1.forEach((s)->System.out.println(s));
        //implicitly stream is closed after terminal operation
        //to explicitly close the stream, call close() method
        //stream1.close();
        //provide source again
        stream1=Stream.of(10,5,20,15,25);
        System.out.println("------------------------");
        stream1.forEach(System.out::println);
        System.out.println("------------------------");
        //Array as a source for stream
        Stream<String> stream2= 
                 Arrays.stream(new String[] {"Core Java","Advance Java",
                                              "Java EE","Spring","JPA"
                                                 }
                                                 );
        stream2.forEach(System.out::println);
        System.out.println("----------------------------");
        //Collection as a source for stream
        List<Long> mobileList= new ArrayList<>();
        mobileList.add(9246776887L); mobileList.add(9846776007L);
        mobileList.add(8446776117L); mobileList.add(9077685790L);
        Stream<Long> stream3=mobileList.stream();
        //stream3.forEach(System.out::println);
        stream3.forEach((m)->System.out.println(m));
        System.out.println("-----------------------------");
        List<Customer> customerList=populateCustomers();
        Stream<Customer> stream4=customerList.stream();
        stream4.forEach(System.out::println);
        System.out.println("Filter examples");
        List<Integer>  listInt1 = Arrays.asList(11,3,44,5,66,33,44);
        listInt1.stream().filter(num -> num > 10).forEach(System.out::println);
        System.out.println("-----------------------------");
        List<Integer>  listInt2 = Arrays.asList(11,3,44,5,66,33,44);
        listInt2.stream().distinct().forEach(System.out::println);
        System.out.println("-----------------------------");
        List<Integer>  listInt3 = Arrays.asList(11,3,44,5,66,33,44);
        listInt3.stream().limit(4).forEach(System.out::println);
        System.out.println("-----------------------------");
        List<Integer>  listInt4 = Arrays.asList(11,3,44,5,66,33,44);
        listInt4.stream().skip(4).forEach(System.out::println);
        System.out.println("Display mobile numbers ending with 0"); 
        Stream<Long> mobileStream=mobileList.stream();
        mobileStream.filter((n)->(n%10)==0).forEach(System.out::println);
        System.out.println("Show customers whose email contains ibm");
        Stream<Customer> customerStream=customerList.stream();
        customerStream
        .filter((c)->c.getEmail().contains("ibm"))
        .forEach(System.out::println);
        System.out.println("----------------------------");
        List<Customer> myList=
                    customerList
                    .stream()
                    .filter((c)->c.getEmail().contains("ibm"))
                    .collect(Collectors.toList());
        myList.stream().forEach(System.out::println);
        System.out.println("Mapping examples...");
        Arrays.stream(new String[] {"Core Java","Advance Java",
                 "Java EE","Spring","JPA"
                    }
                    )
        .map((course)->course.length())
        .forEach(System.out::println);
        System.out.println("------------------------------");
        Arrays.stream(new String[] {"Core Java","Advance Java",
                 "Java EE","Spring","JPA"
                    }
                    )
        .map(String::length).forEach(System.out::println);
        System.out.println("display customer names in upper-case");
        populateCustomers().stream()
        .map((c)->c.getCustomerName().toUpperCase())
        .forEach(System.out::println);
        System.out.println("-------------------------");        
        populateCustomers().stream()
        .map(Customer::getCustomerName)
        .map(String::toUpperCase)
        .forEach(System.out::println);
        System.out.println("Reduce examples...");
        Optional<Integer> optional= Stream.of(10,5,20,15,25)
                                          .reduce((a,b)->a*b);
        if(optional.isPresent()) {
            System.out.println(optional.get());
        }
        System.out.println("display sum of lengths of the strings..");
        
        Optional<Integer> optional1=
                Arrays.stream(new String[] {"Core Java","Advance Java",
                 "Java EE","Spring","JPA"
                    }
                    ).map(String::length).reduce((a,b)->a+b);
        if(optional1.isPresent()) {
            System.out.println(optional1.get());
        }
        System.out.println("Display sum of positive numbers");
        
        Optional<Integer> optional2=
                Arrays.asList(-11,3,-44,5,66,-33,44)
                .stream()
                .filter((n)->n>0).reduce((a,b)->a+b);
        if(optional2.isPresent()) {
            System.out.println(optional2.get());
        }
        System.out.println("Minimum example");
        Optional<Integer> optional3=
                Arrays.asList(-11,3,-44,5,66,-33,44)
                .stream().min((a,b)->a.compareTo(b));
        if(optional3.isPresent()) {
            System.out.println(optional3.get());
        }
        System.out.println("Maximum example");
        
        Optional<Integer> optional4=
                Arrays.asList(-11,3,-44,5,66,-33,44)
                    .stream().max(Integer::compare);
        if(optional4.isPresent()) {
            System.out.println(optional4.get());
        }
        
    }

 

    private static List<Customer> populateCustomers() {
        List<Customer> customerList=new ArrayList<>();
        customerList.add(new Customer(101,"Smith",
                LocalDate.of(1996,10,12),"Mumbai",
                8446776117L,"smith@gmail.com","smith@123"));
        customerList.add(new Customer(105,"Clarke",
                LocalDate.of(1994,5,15),"Pune",
                8446776000L,"clarke@ibm.com","clarke@123"));
        customerList.add(new Customer(102,"Amith",
                LocalDate.of(1991,5,15),"New Delhi",
                8226776089L,"amith@gmail.com","amith@123"));
        return customerList;
    }

 

}

*/