package day5_Lab5_Exercise1;

import java.util.Scanner;

public class AgeTester {
	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		try {
			System.out.println("Enter your age: ");
			int age= scanner.nextInt();
			
			if(age<15) {
				throw new AgeException("You are under-aged, cannot vote , Not Eligible");
			}
			System.out.println("You are eligible to vote");

		}catch(AgeException e) {
			e.printStackTrace();
		}

	}

}
