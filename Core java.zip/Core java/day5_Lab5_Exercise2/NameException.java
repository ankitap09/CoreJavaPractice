package day5_Lab5_Exercise2;

public class NameException extends Exception {
	private String message;

	public NameException() {

	}

	public NameException(String message) {
		this.message=message;
	}
	
	public String getMessage() {
		return this.message;
	}


}
