package day1_lab1;

import java.util.Scanner;

public class Exercise2{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Select Light :");
		String choice = sc.next();
		
		switch(choice) {
		case "Red"  : System.out.println("!!! Stop !!!");
		              break;
		case "Green": System.out.println("!!! Ready !!!");
		              break;
		case "Yellow":System.out.println("!!! Go !!!");
		              break;
		default :break;
		}

	}

}
