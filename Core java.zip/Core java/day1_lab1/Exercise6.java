package day1_lab1;

import java.util.Scanner;

public class Exercise6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter natural number :");
		int n = sc.nextInt();
		
	    Exercise6 object = new Exercise6();
	    int diff = object.calculateDifference(n);
	    
	    System.out.println(diff);
	}

	public int calculateDifference(int n) {
		// TODO Auto-generated method stub
		
		int i=1;
		int sum=0;
		int sq_sum =0;
		
		while(i<=n) {
			sum = sum+i;
			sq_sum = sq_sum + i*i;
			i++;
		}
		
		int x = sum*sum;
		int d = sq_sum - x;
		return d;
	}

}
