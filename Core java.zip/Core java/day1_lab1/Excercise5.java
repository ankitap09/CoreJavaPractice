package day1_lab1;

import java.util.Scanner;

public class Excercise5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int n = sc.nextInt();
		int i=1;
		int sum=0;
		while(i<=n) {
			if(i%3==0 || i%5==0) {
				sum=sum+i;
			}
			i++;	
		}
		System.out.println("Sum of "+n+" Natural numbers divisible by 3 or 5 :"+ sum);
	}

}
