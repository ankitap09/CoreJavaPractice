package day1_lab1;

import java.util.Scanner;
public class Exercise7{

	    public static void main(String args[]) {
	     
	       long num;
	       boolean flag = false;
	       Scanner scanner = new Scanner(System.in);
	       System.out.println("Enter a number : ");
	       num = scanner.nextLong();
	       long currentDigit = num % 10;
	       num = num/10;
	       
	       while(num>0){
	           
	           if(currentDigit <= num % 10){
	               flag = true;
	               break;
	           }

	           currentDigit = num % 10;
	           num = num/10;
	       }
	        
	       if(flag){
	           System.out.println("Digits are not in increasing order.");
	       }else{
	           System.out.println("Digits are in increasing order.");
	       }
	    
	}
}
/*
 * 
import java.util.Scanner;
import java.util.Scanner;

public class Exercise7 {
	private static Scanner sc=new Scanner(System.in);
	public static boolean checkNumber(int num) {
		boolean flag=false; 
		int c=0; 
		while(num>0) {  
			if(c>=num%10) { 
				flag=true;
				break;
			}
			else { 
				flag=false; 
				//return flag;
			}
			c=num%10;
			num=num/10;
		}
		return flag;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a number");
		int n=sc.nextInt();
		boolean flag1=checkNumber(n);
		if(flag1==true) {
			System.out.println("The digits of the number is in increasing order");
		}
		else {
			System.out.println("The digits of the number are not in increasing order");
		}
	}

}
*/
/*
public class Exercise7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number :");
		int n = sc.nextInt();
		
		Exercise7 object = new Exercise7();
		boolean b =object.checkNumber(n);
		if(b==true) {
			System.out.println(n+"is an incresing number");
		}
		else {
			System.out.println("not increasing");
		}
		
	}

	public boolean checkNumber(int n) {
		// TODO Auto-generated method stub
		
		int cnt = 0;
		int rev =0;
		int back = n;
		while(back!=0) {
			rev = rev*10 + back%10;
			back = back/10;
			cnt++;
		}
		
		int i=0,a=0,b=0;
		int flag=0;
		while(i<cnt) {
			a = rev%10;
			rev = rev/10;
			b = rev%10;
			if(a<b) {
				flag=1;
			}
			else {
				flag=0;
				break;
			}
			
			i++;
			
		}
		
		if(flag==1 && cnt==i) {
		return true;
	    }
		
		return false;
	}

}
*/
