package day1_lab1;

import java.util.Scanner;

public class Exercise4{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the integer :");
		int n = sc.nextInt();
		int i=2;
		System.out.println("Prime numbers are :");
		while(i<=n) {
			int j=2;
			int flag=0;
			while(j<=i/2) {
				if(i%j==0) {
					flag=1;
					break;
				}
				j++;
			}
			if(flag==0) {
			System.out.println(i+" ");
			}			
			i++;
		}
	}

}
