package day1_lab1;

import java.util.Scanner;

public class Exercise3 {
	 static int b1=0,b2=1,b3=0;  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int n = sc.nextInt();
		
			//nonrecursive
			nonRecursive(n);  
		
		//recursive
		System.out.println("\n Fibonacii series using recursive : ");
	    System.out.print(b1+" "+b2);//printing 0 and 1    
	    recursiveFibonacci(n-2);//n-2 because 2 numbers are already printed 
			
		
		}

	 static void recursiveFibonacci(int n){    
		    if(n>0){    
		         b3 = b1 + b2;    
		         b1 = b2;    
		         b2 = b3;    
		         System.out.print(" "+b3);   
		         recursiveFibonacci(n-1);    
		     }    
		 }    
	

	public static void nonRecursive(int n) {
		int n1=0,n2=1,n3,i;   
		 System.out.println("Fibonacii series using Nonrecursive : ");
		 System.out.print(n1+" "+n2);//printing 0 and 1    
		    
		 for(i=2;i<n;++i)//loop starts from 2 because 0 and 1 are already printed    
		 {    
		  n3=n1+n2;    
		  System.out.print(" "+n3);    
		  n1=n2;    
		  n2=n3;    
		 }
	}
		

	}


