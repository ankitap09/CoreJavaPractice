package day1_lab1;

import java.util.Scanner;
import java.lang.Math;

public class Exercise1 {
		
		public void findCubes(int n) {
			long sum=0;
			while(n!=0) {
				int a = n%10;
				sum = sum + a*a*a;
				n=n/10;
				
			}
			System.out.println("Sum Of Cubes digits in given number: "+sum);
			
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int n= sc.nextInt();
		Exercise1 object = new Exercise1();
		object.findCubes(n);
	}

}
