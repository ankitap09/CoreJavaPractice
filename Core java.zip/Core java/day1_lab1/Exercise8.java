package day1_lab1;

import java.util.Scanner;

import java.util.Scanner;

public class Exercise8 {
	
	public static boolean isPowerOfTwo(int n) {
	    return n>0 && n==Math.pow(2, Math.round(Math.log(n)/Math.log(2)));
	}
	
	public static Scanner sc=new Scanner(System.in);
	
	
	public static void main(String[] args) {
		System.out.println("Enter number");
		int n=sc.nextInt();
		if(isPowerOfTwo(n))
		System.out.println(n+" is power of 2 ");
		else
		System.out.println(n+" is not power of 2 ");

		
		
		
		
	}

}


/*
public class Exercise8 {
public boolean checkNumber(int n) {
	double value=0;
	int flag=0;
	int i=1;
	while(n>=value){
		value = Math.pow(2, i);
		if(n==value) {
			flag=1;
		}
		
	}
	
	if(flag==1) {
	return true;
	}
	else {
		System.out.println("-----");
		return false;
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter the number :");
       int n = sc.nextInt();
       Exercise8 o = new Exercise8();
       boolean a = o.checkNumber(n);
       System.out.println(n+" power of 2");
	}

}
*/