package day4_Lab4_Exercise1;

public class Account {

}

/*
com.cg.eis.bean
Employee
com.cg.eis.service
Interface: EmployeeService
       public abstract void getEmployeeDetails(Employee employee);
   public abstract String getInsuranceScheme(Employee employee);
   public abstract void showEmployeeDetails(Employee employee);
Implementation class of above interface:
      public class EmployeeServiceImpl  implements EmployeeService{
 
               }




com.cg.eis.pl
Tester class
main()
Employee e1=new Employee();
EmployeeService employeeService = new EmployeeServiceImpl();
employeeService.getEmployeeDetails(e1);
String insuranceScheme= employeeService.getInsuranceScheme(e1);
employeeService.showEmployeeDetails()

*/