package com.cg.eis.bean;

public enum Designation {
	SYSTEM_ASSOCIATE, MANAGER, PROGRAMMER, CRERK
}
